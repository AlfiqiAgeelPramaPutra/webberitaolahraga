<?php
require_once 'koneksi.php';
// menyimpan data kedalam variabel
$id             = $_POST['id'];
$daftarklub     = $_POST['daftar_klub'];
$tanggal        = $_POST['tanggal'];
$waktu          = $_POST['waktu'];
$liga           = $_POST['liga'];
$stadion        = $_POST['stadion'];
// query SQL untuk insert data
$query="UPDATE jadwal SET daftar_klub='$daftarklub',tanggal='$tanggal',waktu='$waktu',liga='$liga',stadion='$stadion' where id='$id'";
mysqli_query($koneksi, $query);
// mengalihkan ke halaman index.php
header("location:index_jadwal.php");
?>