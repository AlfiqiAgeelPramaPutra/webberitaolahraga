<div class="page">
    <h2>Website Berita dan Jual Beli Tiket Terbaik Indonesia</h2>
    <p>Kami berikan berita seputar olahraga indonesia dan jual beli tiket. Fitur terlengkap, harga terjangkau, dan dipasti aman.</p>
</div>