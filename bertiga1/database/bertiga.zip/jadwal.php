<div class="page">
<h2><center>Jadwal Pertandingan</center></h2>
<table border="1">
    <tr>
        <th>No</th>
        <th>Daftar Klub</th>
        <th>Tanggal</th>
        <th>Waktu</th>
        <th>Liga</th>
        <th>Stadion</th>
    </tr>
    <?php
    require_once 'koneksi.php';
    $jadwal = mysqli_query($koneksi, "SELECT * from jadwal");
    $no=1;
    foreach ($jadwal as $jad){
        echo "<tr>
            <td>".$jad['id']."</td>
            <td>".$jad['daftar_klub']."</td>
            <td>".$jad['tanggal']."</td>
            <td>".$jad['waktu']."</td>
            <td>".$jad['liga']."</td>
            <td>".$jad['stadion']."</td>
              </tr>";
        $no++;
    }
    ?>
</table>
</div>