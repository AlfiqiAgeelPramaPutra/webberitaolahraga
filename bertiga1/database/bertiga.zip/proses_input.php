<?php

    require_once "koneksi.php";
    $id = $_POST['id'];
    $daftarklub = $_POST['daftar_klub'];
    $tanggal = $_POST['tanggal'];
    $waktu = $_POST['waktu'];
    $liga = $_POST['liga'];
    $stadion = $_POST['stadion'];
    $insert = mysqli_query($koneksi, "insert into jadwal set id='$id', daftar_klub='$daftarklub', tanggal='$tanggal',  waktu='$waktu',  liga='$liga',  stadion='$stadion'");
echo("data berhasil disimpan")
?>

