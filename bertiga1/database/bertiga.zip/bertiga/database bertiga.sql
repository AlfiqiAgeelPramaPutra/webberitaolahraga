CREATE TABLE IF NOT EXISTS `jadwal` (
  `id` char(5) not null PRIMARY key,
  `daftar_klub` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  `liga` varchar(50) NOT NULL,
  `stadion` varchar(50) NOT NULL);
  
  
 INSERT INTO `jadwal` (`id`,`daftar_klub`, `tanggal`, `waktu`, `liga`, `stadion`) VALUES
('1','Semen Padang Fc Vs Psms Medan','2022-11-12', '17:45:00', 'Liga 2', 'Gelora Bung Karno'),
('2','Sriwijaya Fc Vs Karo United ', '2022-11-13', '18:00:00', 'Liga 2', 'Batakan'),
('3','Borneo Fc Vs PSM Makassar', '2022-12-01', '22:00:00', 'Liga 1', 'Kanjuruhan'),
('4','Persija Vs Persib Bandung', '2022-12-12', '13:30:00', 'Liga1', 'Internasional Jakarta');