<!DOCTYPE html>
<html lang="en">
<head>
    <title>Berita dan Tiket Olahraga | BerTiGa</title>
    <meta charset="UTF-8">
    <meta name="description" contents="BerTIGa">
    <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
    <header class="atas">
        <h1 class="logo">LOGO</h1>
        <button class="daftar">Daftar</button>
        <button class="login">Login</button>
    </header>
    <header>
        <h1 class="title">BerTiGa</h1>
        <h3 class="desc">Berita dan Tiket Olahraga</h3>
        <nav id="navigation">
            <ul>
                <li><a href="index.php?page=home">Home</a></li>
                <li><a href="index.php?page=jadwal">Jadwal</a></li>
                <li><a href="index.php?page=contact">Contact</a></li>
                <li><a href="index.php?page=about">About</a></li>
            </ul>
        </nav>
    </header>
    <div id="contents">
        <?php 
        if(isset($_GET['page'])){
            $page = $_GET['page'];
 
            switch ($page) {
                case 'home':
                include "home.php";
                break;
                case 'jadwal':
                include "jadwal.php";  
                break;
                case 'contact':
                include "contact.php";
                break;  
                case 'about':
                include "about.php";      
            }
        }
else{
            require_once "home.php";
        }
        ?>
 
    </div>
    <footer>
        &copy Copyright BerTiga 2022 | Website Berita dan Jual Beli Tiket Terbaik Indonesia
    </footer>
</body>
</html>