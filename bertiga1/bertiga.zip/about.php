<div class="page">
    <h2><center>Tentang BerTiga</center></h2>
    <p> Kami akan merancang sebuah website dengan tema olahraga, yang mana website ini merupakan gabungan antara website marketplace dengan website berita. 
        Website ini nantinya akan memiliki fungsi utama yaitu penjualan tiket berbagai event olahraga yang ada di Indonesia, 
        seperti penjualan tiket sepakbola Liga 1 dan 2, Event badminton, Voli, Futsal, Moto GP, Tinju, hingga cabang E-Sport. 
        Selain Fungsi utama penjualan tiket, website ini nantinya juga akan berisi berita-berita dan informasi terkini seputar olahraga di Indonesia, 
        yang akan dibagi dalam beberapa kategori olahraga umum yang ada di Indonesia, selain berita nantinya juga akan ada mengenai 
        jadwal pertandingan dan event olahraga yang akan berlangsung di Indonesia. Tujuan kami membuat website ini agar website ini bisa menjadi 
        sarana informasi bagi masyarakat dalam dunia olahraga indonesia, mempermudah masyarakat dalam pembelian tiket pertandingan dan event olahraga, 
        dan juga menampung lalu menyalurkan seluruh kegiatan olahraga dari komunitas atau organisasi di seluruh Indonesia.
    </p>
</div>