<!DOCTYPE html>
<html>
<body>

<form action="upload_process.php" method="post" 
    enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="gambar">
  <input type="submit" value="Upload Image" 
  name="submit">
</form>

</body>
</html>