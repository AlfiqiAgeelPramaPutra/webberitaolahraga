<div class="page">
    <h2>Hubungi Kami</h2>
    <p>Telp: 0274-2885822
        <br>WA: 0895395186038
        <br>Senin - Minggu
    24 Jam Non Stop</p>
 
    <p>Jl. Telekomunikasi. 1, Terusan Buahbatu - Bojongsoang, Telkom University, Sukapura,
     Kec. Dayeuhkolot, Kabupaten Bandung, Jawa Barat 402571</p>
</div>